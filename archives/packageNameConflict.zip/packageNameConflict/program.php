<?php

function main()
{
    echo "packageNameConflict says \"Hello .NET World!\"";    
}

main();
