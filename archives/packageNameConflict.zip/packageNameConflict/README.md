## console-app

Template for creating .NET core console applications in PHP. 

### How to run
1. Install peachpie templates
2. `dotnet new console -lang PHP`
3. `dotnet restore`
4.  Modify `program.php` (optional)
5. `dotnet run`
