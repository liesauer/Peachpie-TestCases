<?php

echo "dot on root: " . realpath('.') . "\n";
