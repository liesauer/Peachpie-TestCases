<?php

require './__dir__on_root.php';
require './dot_on_root.php';

require './child/__dir__on_child.php';
require './child/dot_on_child.php';
