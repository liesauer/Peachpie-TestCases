<?php

echo "__DIR__ on child: " . __DIR__ . "\n";
