<?php

echo "dot on child: " . realpath('.') . "\n";
