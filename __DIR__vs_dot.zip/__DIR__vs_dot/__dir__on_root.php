<?php

echo "__DIR__ on root: " . __DIR__ . "\n";
